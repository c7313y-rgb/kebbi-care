const fs=require('fs'),path=require('path'),C=require('../app/care-core.js');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const sheets=JSON.parse(read('private/master-sheets.json')),master=C.mastersFromSheets(sheets);
fs.writeFileSync(path.join(root,'app/master-seed.js'),'/* LOCAL REVIEW ONLY: private master data. Never publish this file. */\nwindow.MASTER_SEED='+JSON.stringify(master).replace(/</g,'\\u003c')+';\n');
let html=read('app/index.html').replace('<link rel="stylesheet" href="style.css">','<style>'+read('app/style.css')+'</style>');
html=html.replace(/<script src="([^"]+)"><\/script>/g,(_,f)=>'<script>'+read('app/'+f).replace(/<\/script/gi,'<\\/script')+'</script>');
html=html.replace(/assets\/[A-Za-z0-9_\/-]+\.(?:jpg|mp3|wav)/g,f=>{const p=path.join(root,'app',f);if(!fs.existsSync(p))throw Error('Missing asset: '+f);const mime=f.endsWith('.jpg')?'image/jpeg':f.endsWith('.wav')?'audio/wav':'audio/mpeg';return 'data:'+mime+';base64,'+fs.readFileSync(p).toString('base64');});
fs.mkdirSync(path.join(root,'delivery'),{recursive:true});fs.writeFileSync(path.join(root,'delivery/ジェネラス_ケア記録_確認版.html'),html);
console.log(JSON.stringify({residents:master.residents.length,staff:master.staff.length,htmlBytes:Buffer.byteLength(html)}));
