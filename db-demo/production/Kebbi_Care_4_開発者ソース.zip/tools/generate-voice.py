"""Regenerate fixed guide recordings locally on an Apple Silicon Mac.
Install in a dedicated venv: mlx-audio==0.6.5 soundfile imageio-ffmpeg
Only use a voice reference for which reproduction permission has been obtained.
"""
import argparse,json,pathlib,subprocess
import numpy as np
import soundfile as sf
import imageio_ffmpeg
import mlx.core as mx
from mlx_audio.tts.utils import load_model

parser=argparse.ArgumentParser()
parser.add_argument('--reference',required=True,help='Prepared mono 24kHz WAV reference')
parser.add_argument('--reference-text',required=True,help='UTF-8 transcript of exactly that reference')
parser.add_argument('--model',default='mlx-community/Qwen3-TTS-12Hz-1.7B-Base-4bit')
parser.add_argument('--only',nargs='*',help='Cue names to generate; default all')
args=parser.parse_args()
root=pathlib.Path(__file__).resolve().parent.parent
cues=json.loads((root/'docs/voice-cues.json').read_text())
output=root/'app/assets/voice';output.mkdir(parents=True,exist_ok=True)
model=load_model(args.model);ref_text=pathlib.Path(args.reference_text).read_text().strip()
mx.set_cache_limit(192*1024*1024)
for i,key in enumerate(args.only or cues):
    if key not in cues:raise ValueError('Unknown cue: '+key)
    text=cues[key]['text'].replace('CSV','シーエスブイ').replace('PDF','ピーディーエフ').replace('Google Drive','グーグルドライブ').replace('Drive','ドライブ').replace('JSON','ジェイソン').replace('記録一覧','記録の一覧').replace('取込','とりこみ').replace('照合','しょうごう').replace('申し送り','もうしおくり').replace('受取','うけとり').replace('追記','ついき').replace('URL','ユーアールエル')
    mx.random.seed(1121+list(cues).index(key));parts=[]
    for result in model.generate(text=text,lang_code='japanese',ref_audio=args.reference,ref_text=ref_text,temperature=.65,top_p=.9,max_tokens=640):parts.append(np.asarray(result.audio))
    if not parts:raise ValueError('No generated audio: '+key)
    audio=np.concatenate(parts);peak=np.max(np.abs(audio))
    if not np.isfinite(audio).all() or peak<.001:raise ValueError('Invalid audio: '+key)
    if peak>.95:audio*=.95/peak
    wav=output/(key+'.wav');sf.write(wav,audio,result.sample_rate)
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-y','-i',str(wav),'-ac','1','-codec:a','libmp3lame','-b:a','96k',str(output/(key+'.mp3'))],check=True)
    print(key,len(audio)/result.sample_rate,'seconds',flush=True);mx.clear_cache()
