import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--no-sandbox']});
const masters={sites:[{site_id:'test',name:'テスト施設',aliases:[]}],residents:[{resident_id:'U1',display_name:'架空利用者',site_id:'test'}],staff:[{staff_id:'S1',display_name:'架空職員'}]};
try{
 const ctx=await browser.newContext();await ctx.addInitScript(m=>{Object.defineProperty(window,'MASTER_SEED',{get:()=>m,set:()=>{}});window.__speech=[];Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>[],cancel:()=>window.__speech.push('STOP'),speak:u=>window.__speech.push(u.text)}});},masters);
 const p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto('file://'+path.join(root,'app/index.html'));await p.waitForFunction(()=>window.KebbiReview?.getState()?.masters);await p.click('#sampleButton');
 for(const [name,width,height]of [['desktop',1440,1080],['tablet',820,1180],['phone',390,844],['small-phone',320,740],['landscape',844,390]]){
  await p.setViewportSize({width,height});await p.evaluate(()=>KebbiReview.show('dashboard'));assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),name+' dashboard overflow '+JSON.stringify(await p.evaluate(()=>[...document.querySelectorAll('body *')].filter(e=>e.getClientRects().length&&e.getBoundingClientRect().right>innerWidth+1&&!e.closest('.table-wrap')).slice(0,8).map(e=>[e.tagName,e.className,e.getBoundingClientRect().right]))));
  assert.ok(await p.locator('.hero-photo img').evaluate(i=>i.complete&&i.naturalWidth>0));
  await p.screenshot({path:path.join(root,'qa/kebbi-'+name+'.png'),fullPage:name==='desktop'||name==='tablet'});
  for(const view of ['records','upload','settings']){await p.evaluate(v=>KebbiReview.show(v),view);assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),name+' '+view+' overflow');}
  await p.click('#guideLauncher');await p.waitForSelector('#guideDialog[open]');assert.ok(await p.locator('#guideClose').isVisible());assert.equal(await p.evaluate(()=>KebbiGuide.getContext()),'settings');assert.ok(await p.locator('#guideDialog').evaluate(el=>el.getBoundingClientRect().right<=innerWidth+1));
  await p.click('#guideClose');
 }
 await p.setViewportSize({width:390,height:844});await p.evaluate(()=>KebbiReview.show('upload'));await p.click('#guideLauncher');assert.equal(await p.locator('#guideVoice').count(),0);assert.match(await p.locator('#guideVoiceBadge').textContent(),/Kebbi/);assert.deepEqual(await p.evaluate(()=>window.__speech),[]);await p.screenshot({path:path.join(root,'qa/kebbi-guide-phone.png'),fullPage:false});await p.click('#guideClose');await p.evaluate(()=>KebbiReview.show('records'));await p.click('#guideLauncher');assert.match(await p.locator('#guideText').textContent(),/話した内容や要約/);await p.locator('.guide-step').first().click();assert.ok(await p.locator('#filters').evaluate(el=>el.classList.contains('guide-highlight')));
 await p.click('#printButton');await p.waitForFunction(()=>!document.querySelector('#downloadPdf').disabled,{timeout:60000});await p.locator('#pdfDialog [data-guide-open]').click();assert.equal(await p.evaluate(()=>KebbiGuide.getContext()),'pdf');await p.click('#guideClose');await p.locator('#pdfDialog .close-dialog').click();await p.waitForFunction(()=>KebbiGuide.getContext()==='records');assert.equal(await p.evaluate(()=>KebbiGuide.getContext()),'records');
 assert.deepEqual(errors,[]);console.log('PASS: 5 screen sizes, 4 views, supplied photos, touch navigation, contextual guidance, Kebbi-only voice controls, step highlight, PDF guide.');
}finally{await browser.close();}
